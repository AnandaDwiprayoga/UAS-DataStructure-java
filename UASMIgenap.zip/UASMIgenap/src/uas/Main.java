/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas;

import java.util.Scanner;

// ANANDA DWI PRAYOGA
// 1831710119
 // MI-1E
/**
 *
 * @author ASUS
 */
public class Main {

    static void menu() {
        System.out.println("===================================================");
        System.out.println("                    TOKO BUNGA                     ");
        System.out.println("===================================================");
        System.out.println("1. Bunga Masuk");
        System.out.println("2. Bunga Keluar");
        System.out.println("3. Update Bunga Layu");
        System.out.println("4. Lihat Daftar Bunga");
        System.out.println("5. Keluar");
        System.out.print("Masukkan pilihan anda (1-5): ");
    }

    public static void main(String[] args) {
        DoubleLinkedList dll = new DoubleLinkedList();
        Scanner scInt = new Scanner(System.in);
        Scanner scString = new Scanner(System.in);

        // TODO: tambahkan bunga 
        
        Bunga bg = new Bunga("Mawar",3);
        dll.addLast(bg);
        Bunga bg1 = new Bunga("Melati",2);
        dll.addLast(bg1);
        Bunga bg2 = new Bunga("Boreh",1);
        dll.addLast(bg2);
        Bunga bg3 = new Bunga("Flores",5);
        dll.addLast(bg3);
        
        
        boolean pilih = true;

        while (pilih) {
            menu();
            int menu = scInt.nextInt();

            switch (menu) {
                case 1:
                    // TODO: implementasi Bunga Masuk 
                	System.out.print("Nama bunga yang akan di masukkan :");
                	String nama = scString.nextLine();
                	
//                	soal nomer 2
                	int ketemu = dll.cariNamaBunga(nama);
                	int stoklama = 0;
                	if(ketemu!= -1) {
                		dll.remove(ketemu);
                		stoklama = dll.get(ketemu).stok;
                		System.out.println(dll.get(ketemu).nama);
                		System.out.print("Masukkan jumlah stok bunga " + nama + " :");
                    	int stok = scInt.nextInt();
                    	stoklama += stok;
                    	Bunga masuk = new Bunga(nama,stoklama);
                    	dll.add(ketemu, masuk);
                    }else {
                		System.out.print("Masukkan jumlah stok :");
                    	stoklama = scInt.nextInt();
                    	Bunga masuk = new Bunga(nama,stoklama);
                    	dll.addLast(masuk);
                	}
                	
                	
                    break;
                case 2:
                    // TODO: implementasi Bunga Keluar  
                	System.out.print("Masukkan index bunga yang akan dikeluarkan : ");
                	int nomor = scInt.nextInt();
                	dll.remove(nomor);
                    break;
                case 3:
                    // TODO: implementasi Update Bunga Layu
                	
                	System.out.print("Masukkan index bunga yang layu :");
                	int indeklayu = scInt.nextInt();
                	String namaBunga = dll.get(indeklayu).nama;
                	int stokLayu = dll.get(indeklayu).stok;
                	System.out.print("Jumlah bunga " + namaBunga + " yang busuk : " );
                	int jumLayu = scInt.nextInt();
                	Bunga bungaLayu = new Bunga(namaBunga, stokLayu, jumLayu);
                	dll.add(indeklayu, bungaLayu);
                    break;
                case 4:
                    // TODO: implementasi Lihat Daftar Bunga
                	dll.print();
                    break;
                case 5:
                    // TODO: implementasi Keluar 
                	pilih = false;
                    break;
                default:
                    System.out.println("Pilihan menu 1 - 5");
            }
        }
    }
}
