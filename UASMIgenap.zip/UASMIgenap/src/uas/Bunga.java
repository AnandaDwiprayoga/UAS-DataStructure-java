/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas;

/**
 *
 * @author ASUS
 */
public class Bunga {
    public String nama;
    public int stok;
    public int layu;

    public Bunga() {
        this.stok = 0;
        this.layu = 0;
    }

    public Bunga(String nama, int stok) {
        this.nama = nama;
        this.stok = stok;
        this.layu = 0;
    }

    public Bunga(String nama, int stok, int layu) {
        this.nama = nama;
        this.stok = stok;
        this.layu = layu;
    }
}
